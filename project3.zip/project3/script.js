et score = 10;
let highScore = 0;
let guesses = [];
let msgLog = () => document.querySelector("#msg");
let guessContainer = () => document.querySelector(".guess-history");
function youLose() {
    score = 0;
    document.querySelector('.scr').textContent = score;
    msgLog().style.fontSize = '2em';
    msgLog().style.fontWeight = 'bold';
    msgLog().textContent = `GAME OVER`;
    document.querySelector('.btn-check').disabled = true;
    document.querySelector('.user-input').disabled = true;
    document.querySelector('#title').textContent = 'Correct Number Was:';
    document.querySelector('#title').style.color = '#BE1830';
    document.querySelector('.title-box').style.background = '#393A41';
    document.querySelector('.questionLogo').style.fontSize = '4em';
    document.querySelector('.questionLogo').textContent = randomNumber;
    document.querySelector('.msg').style.background = '#BE1830';
    msgLog().style.textShadow = '0px 0px 5px #F1DB4B';
    msgLog().style.color = '#040122';
}
function hint (input, random) {
    if (input > random) {
        msgLog().style.color = "#BE1830";
        msgLog().style.fontSize = "1.5em";
        msgLog().textContent = 'Too High';
    } else {
        msgLog().style.color = "#BE1830";
        msgLog().style.fontSize = "1.2em";
        msgLog().textContent = 'Too Low';
    }
}
function youWin() {
    msgLog().style.color = "#BE1830";
    msgLog().style.fontSize = "2em";
    msgLog().textContent = "YOU WIN! 🎉";

    randomNumber = Math.floor(Math.random() * 100 + 1);
    console.log("NEW RANDOMNUMBER: " + randomNumber);
}

function highscore(scr, hgscr) {
    if (scr > hgscr) {
        hgscr = scr;
        return hgscr;
    } else {
        return hgscr;
    }
}

function wrongInputLayout() {
    msgLog().style.color = "#BE1830";
    msgLog().style.fontSize = "1.25em";
}

let randomNumber = Math.floor(Math.random() * 100 + 1);
console.log("This is RANDOM NUMBER: " + randomNumber);
document.querySelector('.btn-check').addEventListener('click', function() {

    const inputUser = Number(document.querySelector(".user-input").value);
    document.body.style.backgroundColor = '#040122';

    if (!inputUser) {

        wrongInputLayout();
        msgLog().textContent = "Invalid Input";

    } else if (inputUser < 0) {

        wrongInputLayout();
        msgLog().textContent = "Please, enter a positive number";

    } else if (inputUser > 100) {

        wrongInputLayout();
        msgLog().textContent = "Please, enter a number between 1 to 100";

    } else {
        // Displaying the input values on the logo box
        document.querySelector('.questionLogo').style.fontSize = "4em";
        document.querySelector('.questionLogo').textContent = inputUser;
        // Delete value from input box every time the userd hits submit
        document.querySelector('.user-input').value = "";
        // Keep the cursor on the input box
        document.querySelector('.user-input').focus();
        document.querySelector('.user-input').select();


        if (inputUser !== randomNumber && score > 1) {
            guesses.push(inputUser);
            hint(inputUser, randomNumber);
            score --;
            document.querySelector('.scr').textContent = score;
            console.log("this is score " + score);
            while(guessContainer().firstChild) {
                guessContainer().removeChild(guessContainer().firstChild);
            }
            displayGuesses();
        }

        else if (inputUser === randomNumber){
            youWin();
            highScore = highscore(score,highScore);
            document.querySelector('.highestScr').textContent = highScore
            score = 10;
            document.querySelector('.scr').textContent = score;
        }


        else if (score === 1) {
            youLose();
        }
    }
});

document.querySelector('.reset').addEventListener('click',function() {
    // Score reset to 10 and display
    score = 10;
    guesses = [];
    while(guessContainer().firstChild) {
        guessContainer().removeChild(guessContainer().firstChild);
    }
    document.querySelector('.scr').textContent = score;

    highScore = 0;
    document.querySelector('.highestScr').textContent = highScore;

    // Original msg display
    msgLog().textContent = 'Let\'s Start Guessing...';
    msgLog().style.color = "black";
    msgLog().style.fontSize = "1em";


    randomNumber = Math.floor(Math.random() * 100 + 1);
    randomNumber = Math.floor(Math.random() * 100 + 1);
    console.log("RESET RANDOMNUMBER: " + randomNumber);

    // Reset Title
    document.querySelector('#title').textContent = 'Guess My Number';
    document.querySelector('#title').style.color = '#F1DB4B';

    // Reset msg background
    document.querySelector('.msg').style.background = 'none';
     msgLog().style.color = 'white';
     msgLog().style.textShadow = 'none';

    // Reset body background
    document.body.style.backgroundColor = '#040122';

    // Reset title background
    document.querySelector('.title-box').style.background = 'none';
});


function displayGuesses() {

    guesses.forEach(guess => {
        let p = document.createElement('p');
        p.textContent = guess;
        p.style.marginRight = "10px";
        p.style.float = "left";
        guessContainer().appendChild(p);
    });
};
